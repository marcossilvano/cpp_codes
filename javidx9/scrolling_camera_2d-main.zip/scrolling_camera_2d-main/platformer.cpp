#include <iostream>
#include <string>
#define OLC_PGE_APPLICATION
#include "olcPixelGameEngine.h"

class olcPlatformer : public olc::PixelGameEngine {
public:
	olcPlatformer() {
		sAppName = "Tile-based platform game";
	}
private:
	std::wstring sLevel;
	int nLevelWidth;
	int nLevelHeight;

	float fCameraPosX = 0.0f;
	float fCameraPosY = 0.0f;

	bool bPlayerOnGround = false;

	olc::vf2d vPlayerPos = { 0.0f,0.0f };
	olc::vf2d vPlayerVel = { 0.0f,0.0f };

	olc::Renderable rendSpriteTiles;
	olc::Renderable rendCoin;
	olc::Renderable rendMan;

	int nDirModX = 0;
	int nDirModY = 0;

protected:
	bool OnUserCreate() override {
		nLevelWidth = 64;
		nLevelHeight = 20;

		sLevel += L"................................................................";
		sLevel += L"................................................................";
		sLevel += L"....ooooo.......................................................";
		sLevel += L".....ooo........................................................";
		sLevel += L"..................#########.....................................";
		sLevel += L"..BB?BBBB?BB.....###................#.#.........................";
		sLevel += L"...............###..................#.#.........................";
		sLevel += L"..............####..............................................";
		sLevel += L"GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG.############.....##############";
		sLevel += L"...............................#.#.............###..............";
		sLevel += L".................###############.#...........###................";
		sLevel += L".................#...............#.........###..................";
		sLevel += L".................#.###############......###.....................";
		sLevel += L".................#...................###........................";
		sLevel += L".................#####################..........................";
		sLevel += L"................................................................";
		sLevel += L".................#.###############......###.....................";
		sLevel += L".................#...................###........................";
		sLevel += L".................#####################..........................";
		sLevel += L"................................................................";		

		rendCoin.Load("coin.png");
		rendMan.Load("mario.png");
		rendSpriteTiles.Load("blocks.png");

		return true;
	}

	bool OnUserUpdate(float fElapsedTime) override {

		auto GetTile = [&](int x, int y) {
			if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
				return sLevel[y * nLevelWidth + x];
			else
				return L' ';
		};

		auto SetTile = [&](int x, int y, wchar_t c) {
			if (x >= 0 && x < nLevelWidth && y >= 0 && y < nLevelHeight)
				sLevel[y * nLevelWidth + x] = c;
		};

		// Handle input

		vPlayerVel = { 0.0f, 0.0f };

		if (IsFocused()) {
			if (GetKey(olc::Key::UP).bHeld) {
				vPlayerVel.y = -15.0f;
			}
			if (GetKey(olc::Key::DOWN).bHeld) {
				vPlayerVel.y = 15.0f;
			}
			if (GetKey(olc::Key::LEFT).bHeld) {
				vPlayerVel.x += -15.0f;
			}
			if (GetKey(olc::Key::RIGHT).bHeld) {
				vPlayerVel.x += 15.0f;
			}
			// if (GetKey(olc::Key::SPACE).bPressed) {
			// 	if (vPlayerVel.y == 0) {
			// 		vPlayerVel.y = -12.0f;
			// 		nDirModX = 1;
			// 	}
			// }
		}

		// vPlayerVel.y += 20.0f * fElapsedTime; // gravity

		// if (bPlayerOnGround) {
		// 	vPlayerVel.x += -3.0f * vPlayerVel.x * fElapsedTime; // simulating drag
		// 	if (fabs(vPlayerVel.x) < 0.01f) {
		// 		vPlayerVel.x = 0.0f;
		// 	}
		// }

		// // clamp velocities
		// if (vPlayerVel.x > 10.0f)
		// 	vPlayerVel.x = 10.0f;
		// if (vPlayerVel.x < -10.0f)
		// 	vPlayerVel.x = -10.0f;
		// if (vPlayerVel.y > 100.0f)
		// 	vPlayerVel.y = 100.0f;
		// if (vPlayerVel.y < -100.0f)
		// 	vPlayerVel.y = -100.0f;
			
		vPlayerPos += vPlayerVel * fElapsedTime;
		// olc::vf2d vNewPlayerPos = vPlayerPos + vPlayerVel * fElapsedTime; 

		// //Check for coin pickups!
		// // Here we check if any of the 4 corners of the player sprite are intercepting a coin tile
		// //top-left
		// if (GetTile(vNewPlayerPos.x + 0.0f, vNewPlayerPos.y + 0.0f) == L'o')
		// 	SetTile(vNewPlayerPos.x + 0.0f, vNewPlayerPos.y + 0.0f, L'.');
		// //bottom-left
		// if (GetTile(vNewPlayerPos.x + 0.0f, vNewPlayerPos.y + 1.0f) == L'o')
		// 	SetTile(vNewPlayerPos.x + 0.0f, vNewPlayerPos.y + 1.0f, L'.');
		// //top-right
		// if (GetTile(vNewPlayerPos.x + 1.0f, vNewPlayerPos.y + 0.0f) == L'o')
		// 	SetTile(vNewPlayerPos.x + 1.0f, vNewPlayerPos.y + 0.0f, L'.');
		// //bottom-right
		// if (GetTile(vNewPlayerPos.x + 1.0f, vNewPlayerPos.y + 1.0f) == L'o')
		// 	SetTile(vNewPlayerPos.x + 1.0f, vNewPlayerPos.y + 1.0f, L'.');

		// // Collision
		// // Resolving collisions of horizontal movement
		// if (vPlayerVel.x <= 0) { // moving left
		// 	if (GetTile(vNewPlayerPos.x, vPlayerPos.y) != L'.'
		// 		|| GetTile(vNewPlayerPos.x, vPlayerPos.y + 0.9f) != L'.') { // the 0.9 allows the character to fit in gaps that are 1 unit across
		// 		vNewPlayerPos.x = (int)vNewPlayerPos.x + 1;
		// 		vPlayerVel.x = 0;
		// 	}
		// }
		// else { // moving right
		// 	if (GetTile(vNewPlayerPos.x + 1.0f, vPlayerPos.y) != L'.'
		// 		|| GetTile(vNewPlayerPos.x + 1.0f, vPlayerPos.y + 0.9f) != L'.') { // the 0.9 allows the character to fit in gaps that are 1 unit across
		// 		vNewPlayerPos.x = (int)vNewPlayerPos.x;
		// 		vPlayerVel.x = 0;
		// 	}
		// }

		// bPlayerOnGround = false;
		// // Resolving collisions of vertical movement
		// if (vPlayerVel.y <= 0) { //moving up
		// 	if (GetTile(vNewPlayerPos.x, vNewPlayerPos.y) != L'.'
		// 		|| GetTile(vNewPlayerPos.x + 0.9f, vNewPlayerPos.y) != L'.') {
		// 		vNewPlayerPos.y = (int)vNewPlayerPos.y + 1;
		// 		vPlayerVel.y = 0;
		// 	}
		// }
		// else { // moving down
		// 	if (GetTile(vNewPlayerPos.x, vNewPlayerPos.y + 1.0f) != L'.'
		// 		|| GetTile(vNewPlayerPos.x + 0.9f, vNewPlayerPos.y + 1.0f) != L'.') {
		// 		vNewPlayerPos.y = (int)vNewPlayerPos.y;
		// 		vPlayerVel.y = 0;
		// 		bPlayerOnGround = true;
		// 		nDirModX = 0;
		// 	}
		// }

		// vPlayerPos = vNewPlayerPos;

		// Draw Level
		int nTileWidth  = 16;
		int nTileHeight = 16;
		int nVisibleTilesX = ScreenWidth() / nTileWidth;
		int nVisibleTilesY = ScreenHeight() / nTileHeight;

		vPlayerPos.x = std::clamp<float>(vPlayerPos.x, 0.0, nLevelWidth);
		vPlayerPos.y = std::clamp<float>(vPlayerPos.y, 0.0, nLevelHeight);

		fCameraPosX = vPlayerPos.x;
		fCameraPosY = vPlayerPos.y;



		// Calculate Top-Leftmost visible tile
		float fOffsetX = fCameraPosX - (float)nVisibleTilesX / 2.0f;
		float fOffsetY = fCameraPosY - (float)nVisibleTilesY / 2.0f;

		// Clamp camera to game boundaries so it displays at least one full screen on-screen.
		if (fOffsetX < 0) fOffsetX = 0;
		if (fOffsetY < 0) fOffsetY = 0;
		if (fOffsetX > nLevelWidth - nVisibleTilesX) fOffsetX = nLevelWidth - nVisibleTilesX;
		if (fOffsetY > nLevelHeight - nVisibleTilesY) fOffsetY = nLevelHeight - nVisibleTilesY;
		
		// Get offsets for smooth movement
		// How much to displace the tiles by when drawing!
		float fTileOffsetX = (fOffsetX - (int)fOffsetX) * nTileWidth;
		float fTileOffsetY = (fOffsetY - (int)fOffsetY) * nTileHeight;

		Clear(olc::CYAN);

		//Draw visible tile map
		//Overdraw one tile in each direction to get rid of artifacts (the -1 and +1 for both x and y)
		for (int x = -1; x < nVisibleTilesX + 1; x++) {
			for (int y = -1; y < nVisibleTilesY + 1; y++) {
				wchar_t sTileID = GetTile(x + fOffsetX, y + fOffsetY);
				switch (sTileID){
					case L'.':
						FillRect(x * nTileWidth - fTileOffsetX, y * nTileHeight - fTileOffsetY, nTileWidth, nTileHeight, olc::CYAN);
						break;
					case L'#':
						DrawPartialDecal({ x * nTileWidth - fTileOffsetX, y * nTileHeight - fTileOffsetY },
							rendSpriteTiles.Decal(), olc::vf2d{ nTileWidth * 3.0f, 0 }, { nTileWidth * 1.0f, nTileHeight * 1.0f });
						break;
					case L'G':
						DrawPartialDecal({ x * nTileWidth - fTileOffsetX, y * nTileHeight - fTileOffsetY },
							rendSpriteTiles.Decal(), olc::vf2d{ nTileWidth * 2.0f, 0 }, { nTileWidth * 1.0f, nTileHeight * 1.0f });
						break;
					case L'B':
						DrawPartialDecal({ x * nTileWidth - fTileOffsetX, y * nTileHeight - fTileOffsetY },
							rendSpriteTiles.Decal(), olc::vf2d{ nTileWidth * 1.0f, 0 }, { nTileWidth * 1.0f, nTileHeight * 1.0f });
						break;
					case L'?':
						DrawPartialDecal({ x * nTileWidth - fTileOffsetX, y * nTileHeight - fTileOffsetY },
							rendSpriteTiles.Decal(), olc::vf2d{ nTileWidth * 0.0f, 0 }, { nTileWidth * 1.0f, nTileHeight * 1.0f });
						break;
					case L'o':
						DrawPartialDecal({ x * nTileWidth - fTileOffsetX, y * nTileHeight - fTileOffsetY },
							rendCoin.Decal(), olc::vf2d{ nTileWidth * 0.0f, 0 }, { nTileWidth * 1.0f, nTileHeight * 1.0f });
						break;
					default:
						FillRect(x * nTileWidth - fTileOffsetX, y * nTileHeight - fTileOffsetY, nTileWidth, nTileHeight, olc::YELLOW);
						break;
				}
			}
		}

		//draw player
		//FillRect((vPlayerPos.x - fOffsetX) * nTileWidth, (vPlayerPos.y - fOffsetY) * nTileHeight, nTileWidth, nTileHeight, olc::GREEN);
		DrawPartialDecal({ (vPlayerPos.x - fOffsetX)* nTileWidth, (vPlayerPos.y - fOffsetY)* nTileHeight },
			rendMan.Decal(), olc::vf2d{ nTileWidth * nDirModX * 1.0f, nTileHeight * nDirModY * 1.0f }, { nTileWidth * 1.0f, nTileHeight * 1.0f });

		return true;
	}
};

int main() {
	olcPlatformer game;
	if (game.Construct(256, 240, 4, 4))
		game.Start();
	return 0;
}