# Example Workspace for Amiga Assembly extension

This workspace will be downloaded by the Amiga Assembly extension.

Please see the [getting started page](https://github.com/prb28/vscode-amiga-assembly/wiki/Getting-started) to see how to use it.
